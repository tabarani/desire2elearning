# moodlemobile-phonegapbuild
Moodle Mobile repository for Desire2elearning Developed By Innovative Solutions
